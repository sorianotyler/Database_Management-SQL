
ALTER TABLE Species
ADD CONSTRAINT ani CHECK(animalCount >= 0);

ALTER TABLE Members 
ADD CHECK( expirationDate > joinDate);

ALTER TABLE Keepers 
ADD CHECK((keeperLevel IS NOT NULL) OR (keeperSalary IS NULL)); 