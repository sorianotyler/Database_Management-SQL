
CREATE INDEX FindMembers ON Members(name,address);