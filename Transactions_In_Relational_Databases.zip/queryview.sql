
SELECT s.speciesID, s.speciesName, s.animalCount, vcc.computedAnimalCount
  FROM viewComputedCount vcc, Species s
 WHERE vcc.computedAnimalCount <> s.animalCount
   AND s.speciesID = vcc.speciesID;

DELETE FROM Animals 
 WHERE animalID = 10014;
/*lion disappears from queryview's output 

ORIGINAL: 
speciesid | speciesname | animalcount | computedanimalcount 
-----------+-------------+-------------+---------------------
       404 | lion        |           2 |                   3
       405 | panther     |           0 |                   4
       407 | small cat   |           2 |                   4
(3 rows)

NEW: 
speciesid | speciesname | animalcount | computedanimalcount 
-----------+-------------+-------------+---------------------
       405 | panther     |           0 |                   4
       407 | small cat   |           2 |                   4
(2 rows)
*/


DELETE FROM Animals 
 WHERE animalID = 10015;
/*tiger appears from queryview's output 

ORIGINAL: 
speciesid | speciesname | animalcount | computedanimalcount 
-----------+-------------+-------------+---------------------
       404 | lion        |           2 |                   3
       405 | panther     |           0 |                   4
       407 | small cat   |           2 |                   4
(3 rows)

NEW: 
 speciesid | speciesname | animalcount | computedanimalcount 
-----------+-------------+-------------+---------------------
       401 | tiger       |           4 |                   3
       405 | panther     |           0 |                   4
       407 | small cat   |           2 |                   4
(3 rows)

*/
