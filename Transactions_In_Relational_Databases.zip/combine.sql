BEGIN TRANSACTION;
SET TRANSACTION READ WRITE ISOLATION LEVEL SERIALIZABLE;


/*existing tuple*/
UPDATE Animals
   SET animalID = ac.animalID, speciesID = ac.speciesID, cageID = ac.cageID
  FROM AnimalChanges ac
 WHERE ac.animalID = Animals.animalID;

/*no tuple*/ 
INSERT INTO Animals (animalID, speciesID, cageID)
   	 SELECT DISTINCT ac.animalID, ac.speciesID, ac.cageID 
       FROM AnimalChanges ac
      WHERE NOT EXISTS(SELECT * 
				       FROM Animals a
				       WHERE a.animalID = ac.animalID);

 COMMIT;