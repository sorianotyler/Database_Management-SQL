
ALTER TABLE CageVisits
ADD CONSTRAINT cv_constraint foreign key(cageID) references Cages;

ALTER TABLE CageVisits
ADD CONSTRAINT m_constraint foreign key(memberID) references Members;

