
CREATE VIEW viewComputedCount AS
  SELECT s.speciesID, COUNT(a.speciesID) as  computedAnimalCount 
    FROM Animals a, Species s
   WHERE a.speciesID = s.speciesID
GROUP BY s.speciesID
  HAVING COUNT(a.speciesID) >= 3;