
/*two foreign key constriants*/
INSERT INTO CageVisits Values(1001, 208, DATE '8/31/20', TRUE);

INSERT INTO CageVisits Values(1010, 207, DATE '6/5/20', TRUE);

/*two foreign key constriants*/
/*success1*/
UPDATE Species
   SET animalCount = 3
 WHERE speciesID = 405;
/*unsuccess1*/
UPDATE Species
   SET animalCount = -1
 WHERE speciesID = 407;

/*success2*/
UPDATE Members
   SET expirationDate = DATE '6/5/21'
 WHERE memberID = 1009;
/*unsuccess2*/
UPDATE Members
   SET expirationDate = DATE '2/2/19'
 WHERE memberID = 1001;

/*success3*/
 UPDATE Keepers
    SET keeperLevel = NULL, keeperSalary = NULL
  WHERE keeperID = 1;
/*unsuccess3*/
UPDATE Keepers
   SET keeperLevel = NULL, keeperSalary = 1000
 WHERE keeperID = 4;  

