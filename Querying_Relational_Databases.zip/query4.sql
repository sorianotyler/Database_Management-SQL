SELECT DISTINCT m.memberID, m.name
FROM Members m, CageVisits cv, Animals a, Species s
WHERE s.speciesName = 'lion'
  AND a.speciesID = s.speciesID
  AND a.cageID = cv.cageID
  AND cv.memberID = m.memberID
  AND m.name LIKE '%th';
