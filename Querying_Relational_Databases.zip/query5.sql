SELECT DISTINCT a.animalID AS theAnimalID, cv.cageID AS theCageID, a.animalAge AS theAge, k.keeperID AS theKeeperID, k.hireDate AS theHireDate
FROM Species s, Keepers k, CageVisits cv, Cages c, Animals a
WHERE s.speciesName LIKE '%a%'
  AND s.genus IS NOT NULL
  AND s.speciesID = a.speciesID
  AND a.cageID = c.cageID
  AND c.keeperID = k.keeperID
  AND k.hireDate >= DATE '1/2/2019'
  AND k.hireDate <= DATE '12/30/2019'
  AND c.cageID = cv.cageID
  AND cv.likeVisit = 'FALSE';
