SELECT DISTINCT a.animalID
FROM Animals a, Cages c
WHERE c.cageSector = 'N'
  AND c.cageID = a.cageID;