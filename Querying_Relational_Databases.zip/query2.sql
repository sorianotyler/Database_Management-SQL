SELECT m.name, m.address, cv.cageID
FROM Members m, CageVisits cv
WHERE cv.likeVisit = TRUE
  AND m.memberID = cv.memberID;