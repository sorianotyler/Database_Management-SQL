SELECT k.keeperID, k.name, k.keeperSalary
FROM Keepers k, Species s1, Species s2, Cages c, Animals a1, Animals a2
WHERE s1.speciesName = 'lion'
  AND s2.speciesName = 'tiger'
  AND a1.speciesID = s1.speciesID 
  AND a2.speciesID = s2.speciesID
  AND a1.cageID = c.cageID
  AND a2.cageID = c.cageID
  AND c.keeperID = k.keeperID
ORDER BY keeperSalary DESC, k.name ASC;
