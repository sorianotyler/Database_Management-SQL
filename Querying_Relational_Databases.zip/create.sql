CREATE TABLE Keepers
(
keeperID INT NOT NULL,
name VARCHAR(30),
hireDate DATE NOT NULL,
keeperLevel CHAR(1),
keeperSalary NUMERIC(7,2),
PRIMARY KEY (keeperID)
);

CREATE TABLE Cages
(
cageID INT NOT NULL,
cageSector CHAR(1) NOT NULL,
keeperID INT,
PRIMARY KEY (cageID),
FOREIGN KEY (keeperID) references Keepers
);

CREATE TABLE Species
(
speciesID INT NOT NULL,
speciesName VARCHAR(40) NOT NULL,
genus VARCHAR(40),
animalCount INT,
PRIMARY KEY (speciesID),
UNIQUE(speciesName)
);

CREATE TABLE Animals
(
animalID INT NOT NULL,
name VARCHAR(30),
speciesID INT,
animalAge INT,
cageID INT,
PRIMARY KEY (animalID),
FOREIGN KEY (speciesID) references Species,
FOREIGN KEY (cageID) references Cages,
UNIQUE(name, speciesID)
);

CREATE TABLE Members
(
memberID INT NOT NULL,
name VARCHAR(30),
address VARCHAR(40),
memberStatus CHAR(1),
joinDate DATE,
expirationDate DATE,
PRIMARY KEY (memberID),
UNIQUE(name, address)
);

CREATE TABLE CageVisits
(
memberID INT NOT NULL,
cageID INT NOT NULL,
visitDate DATE NOT NULL,
likeVisit BOOLEAN,
PRIMARY KEY (memberID, cageID, visitDate),
FOREIGN KEY (memberID) references Members,
FOREIGN KEY (cageID) references Cages
);
