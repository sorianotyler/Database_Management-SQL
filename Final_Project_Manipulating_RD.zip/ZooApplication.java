import java.sql.*;
import java.util.*;

/**
 * The class implements methods of the Zoo database interface.
 *
 * All methods of the class receive a Connection object through which all
 * communication to the database should be performed. Note: the
 * Connection object should not be closed by any method.
 *
 * Also, no method should throw any exceptions. In particular, in case
 * an error occurs in the database, then the method should print an
 * error message and call System.exit(-1);
 */

public class ZooApplication {

    private Connection connection;

    /*
     * Constructor
     */
    public ZooApplication(Connection connection) {
        this.connection = connection;
    }

    public Connection getConnection()
    {
        return connection;
    }

    /**
     * getMemberStatusCount: This method has a string argument called theMemberStatus, and
     * returns the number of Members whose memberStatus equals theMemberStatus.
     * A value of theMemberStatus that’s not ‘L’, ‘M’ or ‘H’ (corresponding to Low, Medium, and
     * High) is an error.
     */

    public Integer getMemberStatusCount(String theMemberStatus) throws SQLException
    {
        Integer result = 0;
        // your code here
        // Check to see if the memeber status abides by the parameters
        if (!((theMemberStatus.equals("L")) || (theMemberStatus.equals("M")) || (theMemberStatus.equals("H"))))
        {
            System.out.println("Member status is not valid - (not L, M, or H)");
            System.exit(-1);
        }
        // this try block goes into the members schema and counts the number of members with the given member status 
        try
        {
            String query = "SELECT count(*) FROM \"lab4\".Members WHERE memberStatus = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, theMemberStatus);
            stmt.executeQuery();

            // gives the result, returns it, and closes the stamement and the result set 
            ResultSet rSet = stmt.getResultSet();
            rSet.next();
            result = rSet.getInt(1);
            rSet.close();
            stmt.close();
        }
        catch(SQLException e)
        {
            System.out.println("There was an errror!");
            System.exit(-1);
        }
        // end of your code
        return result;
    }


    /**
     * updateMemberAddress:  Sometimes a member changes address.  The updateMemberAddress method
     * has two arguments, an integer argument theMemberID, and a string argument,
     * newMemberAddress.  For the tuple in the Members table (if any) whose memberID equals
     * theMemberID, updateMemberAddress should update the address to be newMemberAddress.
     * (Note that there might not be any tuples whose memberID matches theMemberID.)
     *
     * updateMemberAddress should return the number of tuples that were updated, which will
     * always be 0 or 1.
     */

    public int updateMemberAddress(int theMemberID, String newMemberAddress)
    {
        // your code here; return 0 appears for now to allow this skeleton to compile.
        int result = 0; // automatically set to 0 aka unsuccessful 
        // this try block updates the member address with the new memeber address 
        try
        {
            String query = "UPDATE \"lab4\".Members SET address = ? WHERE memberID = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, newMemberAddress);
            stmt.setInt(2, theMemberID);

            // counts if it is done succesfully
            stmt.execute();
            result = stmt.getUpdateCount();
            stmt.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            System.exit(-1);
        }

        return result;
        
        // end of your code
    }


    /**
     * increaseSomeKeeperSalaries: This method has an integer parameter, maxIncreaseAmount.
     * It invokes a stored function increaseSomeKeeperSalariesFunction that you will need to
     * implement and store in the database according to the description in Section 5.
     * increaseSomeKeeperSalariesFunction should have the same parameter, maxIncreaseAmount.
     * A value of maxIncreaseAmount that’s not positive is an error.
     *
     * The Keepers table has a keeperSalary attribute, which gives the salary (in dollars and
     * cents) for each keepers.  increaseSomeKeeperSalariesFunction will increase the salary
     * for some (but not necessarily all) keepers; Section 5 explains which keepers should have
     * their salaries increased, and also tells you how much they should be increased.
     * The increaseSomeKeeperSalaries method should return the same integer result that the
     * increaseSomeKeeperSalariesFunction stored function returns.
     *
     * The increaseSomeKeeperSalaries method must only invoke the stored function
     * increaseSomeKeeperSalariesFunction, which does all of the assignment work; do not
     * implement the increaseSomeKeeperSalaries method using a bunch of SQL statements through
     * JDBC.
     */

    public int increaseSomeKeeperSalaries (int maxIncreaseAmount)
    {
        // There's nothing special about the name storedFunctionResult
        int storedFunctionResult = 0; 
      
        if(maxIncreaseAmount <= 0)
        {
            System.exit(-1);
        }
        // counts the amount that is changed by putting it through the stored funciton. 
        try
        {
            String query = "SELECT \"lab4\".increaseSomeKeeperSalariesFunction(?)";
            PreparedStatement stmt = connection.prepareStatement(query);
                stmt.setInt(1, maxIncreaseAmount);
                stmt.executeQuery();
            ResultSet resultSet = stmt.getResultSet();
            if(resultSet.next())
                storedFunctionResult = resultSet.getInt(1);

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return storedFunctionResult;

    }

};
