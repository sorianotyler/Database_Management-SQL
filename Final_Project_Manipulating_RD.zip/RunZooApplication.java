import java.sql.*;
import java.io.*;
import java.util.*;

/**
 * A class that connects to PostgreSQL and disconnects.
 * You will need to change your credentials below, to match the usename and password of your account
 * in the PostgreSQL server.
 * The name of your database in the server is the same as your username.
 * You are asked to include code that tests the methods of the ZooApplication class
 * in a similar manner to the sample RunFilmsApplication.java program.
*/


public class RunZooApplication
{
    public static void main(String[] args) {
    	
    	Connection connection = null;
    	try {
    	    //Register the driver
    		Class.forName("org.postgresql.Driver"); 
    	    // Make the connection.
            // You will need to fill in your real username (twice) and password for your
            // Postgres account in the arguments of the getConnection method below.
            connection = DriverManager.getConnection(
                                                     "jdbc:postgresql://cse182-db.lt.ucsc.edu/tsoriano",
                                                     "tsoriano",
                                                     "@Ha9935ef");
            
            if (connection != null)
                System.out.println("Connected to the database!");

            /* Include your code below to test the methods of the ZooApplication class.
             * The sample code in RunFilmsApplication.java should be useful.
             * That code tests other methods for a different database schema.
             * Your code below: */
                ZooApplication app = new ZooApplication(connection);
                
                // this test the get member status count
                // This should count the number of members with status H and output that number in the text given in the lab4 PDF 
                String memberStatus = "H";
                Integer memeberStatusCount = app.getMemberStatusCount(memberStatus);
                System.out.println("Output of getMemberStatusCount");
                System.out.println("when the parameter theMemberStatus is '" + memberStatus + "'.");
                System.out.println(memeberStatusCount);

                // this tests update member status1
                // This should change the address for the member with ID 1006 to 200 rocky road 
                // If it successfully does that you should see the line that was provided in the lab4 PDF and A 1 (meaning it successfully changed it)
                Integer theMemberID1 = 1006;
                String newMemberAddress1 = "200 Rocky Road";
                Integer updateResult1 = app.updateMemberAddress(theMemberID1, newMemberAddress1);
                System.out.println("Output of updateMemberAddress when theMemberID is 1006 ");
                System.out.println("and newMemberAddress is '"+ newMemberAddress1 + "' " );
                System.out.println(updateResult1);

                // this tests update member status2
                // This should change the address for the member with ID 1011 to 200 rocky road 
                // If it successfully does that you should see the line that was provided in the lab4 PDF and A 0 (meaning it unsuccessfully changed it)
                // It doesnt change it for there is no member with the ID 1011
                Integer theMemberID2 = 1011;
                String newMemberAddress2 = "300 Rocky Road";
                Integer updateResult2 = app.updateMemberAddress(theMemberID2, newMemberAddress2);
                System.out.println("Output of updateMemberAddress when theMemberID is 1011 ");
                System.out.println("and newMemberAddress is '" +newMemberAddress2 + "' " );
                System.out.println(updateResult2);

                // This tests increase some keeper salaries
                // The maxIncreaseAmount is 450 and will be put through the stored function.  
                // This should outupt 400 for in the lab4 PDF we see that any number > 400 will give us 400;
                Integer increaseResult1 = app.increaseSomeKeeperSalaries(451);
                System.out.println("The Output for increaseResult1 is " +increaseResult1);

                // This tests increase some keeper salaries
                // The maxIncreaseAmount is 132 and will be put through the stored function.  
                // This should outupt 120 for in the lab4 PDF the function the increase result cannot be > the max increase amount 
                // in this case, since all the A keepers had their salaries increased already, the B keeper are the only one that can be added to (in increments of 20)
                // Therefore 120 is the correct output. 
                Integer increaseResult2 = app.increaseSomeKeeperSalaries(132);
                System.out.println("The Output for increaseResult2 is " +increaseResult2);


            
            /*******************
            * Your code ends here */
            
    	}
    	catch (SQLException | ClassNotFoundException e) {
    		System.out.println("Error while connecting to database: " + e);
    		e.printStackTrace();
    	}
    	finally {
    		if (connection != null) {
    			// Closing Connection
    			try {
					connection.close();
				} catch (SQLException e) {
					System.out.println("Failed to close connection: " + e);
					e.printStackTrace();
				}
    		}
    	}
    }
}
